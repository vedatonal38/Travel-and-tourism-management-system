package com.vedat.config;

/**
 *
 * @author Vedat Önal
 */
public interface Config {

    public int maxInterval = 60 * 60 * 24;

}
